/*******************************************************************************
*
* Purpose: Square area calculator.  Outputs caculated square areas from 
* side length provided via standard input... outputs them with a unit 
* provided as 2nd argv values.  i.e. if we run with ""./square inches" expect 
* output of the format: 50 inches
*
*******************************************************************************/
#include <stdio.h>
#include "library.h"

int main(int argc, char *argv[])
{
  int m = 0;

  // Check for correct number of arguments
  if (argc != 2)
  {
    printf("Incorrect number of arguments provided.\n");
    return 0;
  }

  // read in side lengths and multiply to get area
  while (scanf("%d", &m) != EOF)
  {
    printf("%d %s\n", multiply(m, m), argv[1]);
  }
  
  return 0;
}