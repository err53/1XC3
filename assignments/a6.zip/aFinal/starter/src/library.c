/*******************************************************************************
*
* Purpose: Library function definitions
*
*******************************************************************************/

int square_area(int side) { return side * side; }

int multiply(int m, int n) { return m * n; }